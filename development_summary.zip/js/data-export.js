// Get jsPDF from window object
const { jsPDF } = window.jspdf;

// Make functions globally accessible
window.deleteRow = function(button) {
    const row = button.closest('tr');
    const tableBody = document.getElementById('dataTableBody');
    const clearButton = document.getElementById('clearData');
    
    // Remove the row with animation
    row.style.transition = 'all 0.3s ease';
    row.style.opacity = '0';
    row.style.transform = 'translateX(20px)';
    
    setTimeout(() => {
        row.remove();
        // Hide clear all button if no data left
        if (tableBody.children.length === 0 && clearButton) {
            clearButton.style.display = 'none';
        }
    }, 300);
};

window.clearDataPreview = function() {
    const tableBody = document.getElementById('dataTableBody');
    const clearButton = document.getElementById('clearData');
    const rows = Array.from(tableBody.getElementsByTagName('tr'));
    
    // If no rows, just return
    if (rows.length === 0) return;
    
    // Disable the clear button to prevent multiple clicks
    if (clearButton) {
        clearButton.disabled = true;
        clearButton.style.opacity = '0.7';
    }
    
    // Animate each row with a slight delay
    rows.forEach((row, index) => {
        setTimeout(() => {
            row.style.transition = 'all 0.3s ease';
            row.style.opacity = '0';
            row.style.transform = 'translateX(20px)';
        }, index * 50); // Stagger the animation
    });
    
    // Remove all rows after animations complete
    setTimeout(() => {
        tableBody.innerHTML = '';
        if (clearButton) {
            clearButton.style.display = 'none';
            clearButton.disabled = false;
            clearButton.style.opacity = '1';
        }
    }, (rows.length * 50) + 300); // Wait for all animations to complete
};

// Initialize AOS animations and setup
document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 800,
        easing: 'ease',
        once: false
    });

    // Set default dates
    const today = new Date();
    const lastMonth = new Date();
    lastMonth.setMonth(today.getMonth() - 1);
    
    document.getElementById('startDate').valueAsDate = lastMonth;
    document.getElementById('endDate').valueAsDate = today;

    // Generate and display initial data
    generateAndDisplayData();

    // Event Listeners
    document.getElementById('filterData').addEventListener('click', generateAndDisplayData);
    document.getElementById('exportExcel').addEventListener('click', handleExcelExport);
    document.getElementById('exportCSV').addEventListener('click', handleCSVExport);
    document.getElementById('exportPDF').addEventListener('click', handlePDFExport);
    document.getElementById('clearData').addEventListener('click', clearDataPreview);

    // Show clear button if there's initial data
    const tableBody = document.getElementById('dataTableBody');
    const clearButton = document.getElementById('clearData');
    if (clearButton && tableBody.children.length > 0) {
        clearButton.style.display = 'inline-flex';
    }
});

// Function to format date
function formatDate(date) {
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

// Function to generate realistic sensor data
function generateRealisticValue(min, max, prevValue = null) {
    if (prevValue === null) {
        return Number((Math.random() * (max - min) + min).toFixed(1));
    }
    // Generate value close to previous value for more realistic data
    const maxChange = (max - min) * 0.1; // 10% maximum change
    const change = (Math.random() * maxChange * 2) - maxChange;
    const newValue = Math.max(min, Math.min(max, prevValue + change));
    return Number(newValue.toFixed(1));
}

// Function to generate sample data
function generateSampleData() {
    const startDate = new Date(document.getElementById('startDate').value);
    const endDate = new Date(document.getElementById('endDate').value);
    const data = [];
    
    let prevMoisture = null;
    let prevTemperature = null;
    let prevHumidity = null;

    for (let date = new Date(startDate); date <= endDate; date.setHours(date.getHours() + 2)) {
        // Generate more realistic values with gradual changes
        prevMoisture = generateRealisticValue(35, 55, prevMoisture);
        prevTemperature = generateRealisticValue(20, 28, prevTemperature);
        prevHumidity = generateRealisticValue(55, 75, prevHumidity);

        data.push({
            timestamp: formatDate(date),
            moisture: prevMoisture,
            temperature: prevTemperature,
            humidity: prevHumidity,
            status: getStatus(prevMoisture, prevTemperature, prevHumidity)
        });
    }

    return data;
}

// Function to determine status based on sensor values
function getStatus(moisture, temperature, humidity) {
    if (moisture < 40) return 'Low Moisture';
    if (moisture > 50) return 'High Moisture';
    if (temperature < 22) return 'Low Temperature';
    if (temperature > 26) return 'High Temperature';
    if (humidity < 60) return 'Low Humidity';
    if (humidity > 70) return 'High Humidity';
    return 'Normal';
}

// Function to get status color
function getStatusColor(status) {
    switch(status) {
        case 'Normal': return '#2ecc71';
        case 'Low Moisture':
        case 'Low Temperature':
        case 'Low Humidity': return '#3498db';
        case 'High Moisture':
        case 'High Temperature':
        case 'High Humidity': return '#e74c3c';
        default: return '#95a5a6';
    }
}

// Function to display data in table
function generateAndDisplayData() {
    const data = generateSampleData();
    const tableBody = document.getElementById('dataTableBody');
    const clearButton = document.getElementById('clearData');
    tableBody.innerHTML = '';

    data.forEach(row => {
        const tr = document.createElement('tr');
        const status = row.status;
        const statusColor = getStatusColor(status);
        
        tr.innerHTML = `
            <td>${row.timestamp}</td>
            <td>
                <div class="value-container">
                    <span class="value">${row.moisture.toFixed(1)}</span>
                    <span class="unit">%</span>
                </div>
            </td>
            <td>
                <div class="value-container">
                    <span class="value">${row.temperature.toFixed(1)}</span>
                    <span class="unit">°C</span>
                </div>
            </td>
            <td>
                <div class="value-container">
                    <span class="value">${row.humidity.toFixed(1)}</span>
                    <span class="unit">%</span>
                </div>
            </td>
            <td>
                <div class="action-container">
                    <span class="status-badge" style="background-color: ${statusColor}">${status}</span>
                    <button class="delete-btn" onclick="deleteRow(this)">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        tableBody.appendChild(tr);
    });

    // Show the clear all button if there's data
    if (clearButton) {
        clearButton.style.display = data.length > 0 ? 'inline-flex' : 'none';
    }

    return data;
}

// Function to handle Excel export
function handleExcelExport() {
    try {
        const data = generateSampleData();
        const exportData = data.map(row => ({
            Timestamp: row.timestamp,
            'Moisture (%)': row.moisture.toFixed(1),
            'Temperature (°C)': row.temperature.toFixed(1),
            'Humidity (%)': row.humidity.toFixed(1),
            Status: row.status
        }));

        const ws = XLSX.utils.json_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Sensor Data");
        
        // Save the file
        XLSX.writeFile(wb, "AGROkaka_sensor_data.xlsx");
    } catch (error) {
        console.error('Excel Export Error:', error);
        alert('Error exporting to Excel. Please try again.');
    }
}

// Function to handle CSV export
function handleCSVExport() {
    try {
        const data = generateSampleData();
        let csvContent = "data:text/csv;charset=utf-8,";
        
        // Add headers
        csvContent += "Timestamp,Moisture (%),Temperature (°C),Humidity (%),Status\n";
        
        // Add data rows
        data.forEach(row => {
            csvContent += `${row.timestamp},${row.moisture.toFixed(1)},${row.temperature.toFixed(1)},${row.humidity.toFixed(1)},${row.status}\n`;
        });
        
        // Create download link
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "AGROkaka_sensor_data.csv");
        document.body.appendChild(link);
        
        // Trigger download
        link.click();
        document.body.removeChild(link);
    } catch (error) {
        console.error('CSV Export Error:', error);
        alert('Error exporting to CSV. Please try again.');
    }
}

// Function to handle PDF export
function handlePDFExport() {
    try {
        const doc = new jsPDF();

        // Add title
        doc.setFontSize(16);
        doc.text("AGROkaka Sensor Data Report", 15, 15);

        // Add date range
        doc.setFontSize(12);
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        doc.text(`Date Range: ${startDate} to ${endDate}`, 15, 25);

        // Get data and prepare for table
        const data = generateSampleData();
        const tableData = data.map(row => [
            row.timestamp,
            `${row.moisture.toFixed(1)}%`,
            `${row.temperature.toFixed(1)}°C`,
            `${row.humidity.toFixed(1)}%`,
            row.status
        ]);

        // Add table using autoTable plugin
        doc.autoTable({
            head: [['Timestamp', 'Moisture', 'Temperature', 'Humidity', 'Status']],
            body: tableData,
            startY: 35,
            theme: 'grid',
            styles: { 
                fontSize: 8,
                cellPadding: 2
            },
            headStyles: { 
                fillColor: [42, 157, 143],
                textColor: [255, 255, 255]
            },
            columnStyles: {
                0: { cellWidth: 45 },
                1: { cellWidth: 25 },
                2: { cellWidth: 25 },
                3: { cellWidth: 25 },
                4: { cellWidth: 30 }
            }
        });

        // Add chart
        try {
            const chartData = generateChartData(data);
            addChartToPDF(doc, chartData);
        } catch (chartError) {
            console.error('Chart generation error:', chartError);
            // Continue without chart if there's an error
        }

        // Save the PDF
        doc.save("AGROkaka_sensor_data_report.pdf");
    } catch (error) {
        console.error('PDF Export Error:', error);
        alert('Error generating PDF. Please try again.');
    }
}

// Function to generate chart data
function generateChartData(data) {
    return {
        labels: data.map(row => row.timestamp),
        datasets: [
            {
                label: 'Moisture (%)',
                data: data.map(row => row.moisture),
                borderColor: 'rgb(67, 97, 238)',
                tension: 0.4
            },
            {
                label: 'Temperature (°C)',
                data: data.map(row => row.temperature),
                borderColor: 'rgb(239, 71, 111)',
                tension: 0.4
            },
            {
                label: 'Humidity (%)',
                data: data.map(row => row.humidity),
                borderColor: 'rgb(6, 214, 160)',
                tension: 0.4
            }
        ]
    };
}

// Function to add chart to PDF
function addChartToPDF(doc, chartData) {
    try {
        // Create a temporary canvas for the chart
        const canvas = document.createElement('canvas');
        canvas.width = 800;
        canvas.height = 400;
        const ctx = canvas.getContext('2d');

        // Create and render the chart
        new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                responsive: false,
                animation: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: 'Sensor Data Trends'
                    }
                }
            }
        });

        // Add the chart to the PDF
        const chartImage = canvas.toDataURL('image/png');
        doc.addPage();
        doc.text('Sensor Data Visualization', 15, 15);
        doc.addImage(chartImage, 'PNG', 10, 30, 190, 100);
    } catch (error) {
        console.error('Error adding chart to PDF:', error);
        // Continue without the chart if there's an error
    }
} 