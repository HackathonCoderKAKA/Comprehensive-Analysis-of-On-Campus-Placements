// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS animations
    AOS.init({
        duration: 800,
        easing: 'ease',
        once: false
    });

    // Hide preloader when page is loaded
    window.addEventListener('load', function() {
        const preloader = document.querySelector('.preloader');
        preloader.classList.add('hidden');
        setTimeout(() => {
            preloader.style.display = 'none';
        }, 500);
    });

    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
    }

    // Dark mode toggle
    const themeToggle = document.querySelector('.theme-toggle');
    
    if (themeToggle) {
        // Check for saved theme preference
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-theme');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }

        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-theme');
            
            if (document.body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
                themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            } else {
                localStorage.setItem('theme', 'light');
                themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            }
        });
    }

    // Initialize Chart
    let sensorChart;
    function initChart() {
        const ctx = document.getElementById("sensorChart");
        if (!ctx) return;

        const chartCtx = ctx.getContext("2d");
        
        // Generate sample data for initial display
        const sampleLabels = [];
        const moistureData = [];
        const temperatureData = [];
        const humidityData = [];
        
        // Create data for the last 10 time points
        for (let i = 9; i >= 0; i--) {
            const date = new Date();
            date.setMinutes(date.getMinutes() - i);
            sampleLabels.push(date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}));
            
            // Generate random data within realistic ranges
            moistureData.push(Math.floor(Math.random() * 20) + 35); // 35-55%
            temperatureData.push(Math.floor(Math.random() * 8) + 20); // 20-28°C
            humidityData.push(Math.floor(Math.random() * 20) + 55); // 55-75%
        }
        
        sensorChart = new Chart(chartCtx, {
            type: "line",
            data: {
                labels: sampleLabels,
                datasets: [
                    { 
                        label: "Moisture", 
                        data: moistureData, 
                        borderColor: "rgb(67, 97, 238)",
                        backgroundColor: "rgba(67, 97, 238, 0.1)",
                        tension: 0.4,
                        fill: true
                    },
                    { 
                        label: "Temperature", 
                        data: temperatureData, 
                        borderColor: "rgb(239, 71, 111)",
                        backgroundColor: "rgba(239, 71, 111, 0.1)",
                        tension: 0.4,
                        fill: true
                    },
                    { 
                        label: "Humidity", 
                        data: humidityData, 
                        borderColor: "rgb(6, 214, 160)",
                        backgroundColor: "rgba(6, 214, 160, 0.1)",
                        tension: 0.4,
                        fill: true
                    },
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Sensor Data Over Time'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
    }

    // Function to Update Values
    function updateValues() {
        const moisture = document.getElementById("inputMoisture").value || 0;
        const temperature = document.getElementById("inputTemperature").value || 0;
        const humidity = document.getElementById("inputHumidity").value || 0;

        // Update text display
        const moistureElement = document.getElementById("moisture");
        const temperatureElement = document.getElementById("temperature");
        const humidityElement = document.getElementById("humidity");

        if (moistureElement) moistureElement.innerHTML = moisture + "<span>%</span>";
        if (temperatureElement) temperatureElement.innerHTML = temperature + "<span>°C</span>";
        if (humidityElement) humidityElement.innerHTML = humidity + "<span>%</span>";

        // Update gauge fills
        updateGauges(moisture, temperature, humidity);

        // Update chart
        updateChart({ moisture, temperature, humidity });
    }

    // Function to update gauge fills
    function updateGauges(moisture, temperature, humidity) {
        const moistureGauge = document.querySelector('.moisture .gauge-fill');
        const temperatureGauge = document.querySelector('.temperature .gauge-fill');
        const humidityGauge = document.querySelector('.humidity .gauge-fill');

        if (moistureGauge) moistureGauge.style.width = `${moisture}%`;
        
        // Temperature scale from -20 to 50 (70 degree range)
        if (temperatureGauge) {
            const tempPercentage = ((parseFloat(temperature) + 20) / 70) * 100;
            temperatureGauge.style.width = `${Math.min(Math.max(tempPercentage, 0), 100)}%`;
        }
        
        if (humidityGauge) humidityGauge.style.width = `${humidity}%`;
    }

    // Function to Update Chart
    function updateChart(data) {
        if (!sensorChart) return;
        
        const time = new Date().toLocaleTimeString();

        if (sensorChart.data.labels.length > 10) {
            sensorChart.data.labels.shift();
            sensorChart.data.datasets.forEach(dataset => dataset.data.shift());
        }

        sensorChart.data.labels.push(time);
        sensorChart.data.datasets[0].data.push(data.moisture);
        sensorChart.data.datasets[1].data.push(data.temperature);
        sensorChart.data.datasets[2].data.push(data.humidity);

        sensorChart.update();
    }

    // Initialize the chart
    initChart();

    // Add event listener to update button
    const updateBtn = document.getElementById('updateBtn');
    if (updateBtn) {
        updateBtn.addEventListener('click', updateValues);
    }

    // Chatbot functionality
    const chatbotToggle = document.querySelector('.chatbot-toggle');
    const chatbotBox = document.querySelector('.chatbot-box');
    const chatbotClose = document.querySelector('.chatbot-close');
    const chatInput = document.getElementById('chatInput');
    const sendMessage = document.getElementById('sendMessage');
    const chatMessages = document.querySelector('.chatbot-messages');

    // Toggle chatbot visibility
    if (chatbotToggle && chatbotBox) {
        chatbotToggle.addEventListener('click', function() {
            chatbotBox.classList.add('active');
        });
    }

    if (chatbotClose && chatbotBox) {
        chatbotClose.addEventListener('click', function() {
            chatbotBox.classList.remove('active');
        });
    }

    // Function to add message to chat
    function addMessage(message, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');
        messageDiv.classList.add(isUser ? 'user' : 'bot');
        
        const messageContent = document.createElement('div');
        messageContent.classList.add('message-content');
        messageContent.textContent = message;
        
        messageDiv.appendChild(messageContent);
        chatMessages.appendChild(messageDiv);
        
        // Scroll to bottom of chat
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Function to process user message and generate response
    function processMessage(userMessage) {
        // Simple chatbot responses based on keywords
        const lowerMessage = userMessage.toLowerCase();
        let botResponse = '';

        if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
            botResponse = 'Hello! How can I help you with your soil monitoring today?';
        } 
        else if (lowerMessage.includes('moisture') || lowerMessage.includes('water')) {
            botResponse = 'Our moisture sensors provide real-time data on soil water content. Optimal moisture levels depend on your crop type, but generally range between 20-60%.';
        }
        else if (lowerMessage.includes('temperature')) {
            botResponse = 'Temperature monitoring is crucial for plant health. Most plants thrive in soil temperatures between 18-24°C (65-75°F).';
        }
        else if (lowerMessage.includes('humidity')) {
            botResponse = 'Ambient humidity affects plant transpiration. For most plants, 40-60% relative humidity is ideal.';
        }
        else if (lowerMessage.includes('data') || lowerMessage.includes('export')) {
            botResponse = 'You can export your sensor data to Excel by visiting the Data Export page. This allows you to analyze trends over time.';
        }
        else if (lowerMessage.includes('help')) {
            botResponse = 'I can help with questions about soil moisture, temperature, humidity, data export, and general system usage. What would you like to know?';
        }
        else {
            botResponse = 'I\'m not sure I understand. Could you rephrase your question? You can ask about moisture, temperature, humidity, or data export.';
        }

        return botResponse;
    }

    // Send message when button is clicked
    if (sendMessage && chatInput) {
        sendMessage.addEventListener('click', function() {
            const message = chatInput.value.trim();
            if (message !== '') {
                addMessage(message, true);
                chatInput.value = '';
                
                // Simulate typing delay
                setTimeout(() => {
                    const response = processMessage(message);
                    addMessage(response);
                }, 1000);
            }
        });
    }

    // Send message when Enter key is pressed
    if (chatInput) {
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const message = chatInput.value.trim();
                if (message !== '') {
                    addMessage(message, true);
                    chatInput.value = '';
                    
                    // Simulate typing delay
                    setTimeout(() => {
                        const response = processMessage(message);
                        addMessage(response);
                    }, 1000);
                }
            }
        });
    }

    // Excel data export functionality
    function exportToExcel() {
        // This is a simplified version - in a real app, you'd use a library like SheetJS
        // or send data to a server for proper Excel file generation
        
        // Create a CSV string
        let csvContent = "data:text/csv;charset=utf-8,";
        csvContent += "Timestamp,Moisture (%),Temperature (°C),Humidity (%)\n";
        
        // Add current values
        const moisture = document.getElementById("moisture").textContent.replace('%', '') || 0;
        const temperature = document.getElementById("temperature").textContent.replace('°C', '') || 0;
        const humidity = document.getElementById("humidity").textContent.replace('%', '') || 0;
        
        const timestamp = new Date().toLocaleString();
        csvContent += `${timestamp},${moisture},${temperature},${humidity}\n`;
        
        // Create download link
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "sensor_data.csv");
        document.body.appendChild(link);
        
        // Trigger download
        link.click();
        document.body.removeChild(link);
    }

    // Add export button functionality if on data page
    const exportButton = document.getElementById('exportButton');
    if (exportButton) {
        exportButton.addEventListener('click', exportToExcel);
    }
}); 