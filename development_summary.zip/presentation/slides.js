const slides = [
    {
        title: "KakaPharmacy - Smart Soil Monitoring System",
        subtitle: "A Modern Solution for Agricultural Excellence",
        content: `
            <ul>
                <li>Next-generation soil monitoring system</li>
                <li>Real-time data tracking</li>
                <li>Smart analytics and reporting</li>
                <li>User-friendly interface</li>
            </ul>
        `
    },
    {
        title: "Real-Time Monitoring Dashboard",
        subtitle: "Live Tracking System",
        content: `
            <ul>
                <li><strong>Soil Moisture:</strong> 35-55% range monitoring</li>
                <li><strong>Temperature:</strong> 20-28°C tracking</li>
                <li><strong>Humidity:</strong> 55-75% measurement</li>
                <li><strong>Visual Gauges:</strong> Instant status feedback</li>
                <li><strong>Color Coding:</strong> Green (Normal), Blue (Low), Red (High)</li>
            </ul>
        `
    },
    {
        title: "Data Visualization",
        subtitle: "Interactive Analytics",
        content: `
            <ul>
                <li>Dynamic trend charts</li>
                <li>Historical data comparison</li>
                <li>Real-time updates</li>
                <li>Custom date range selection</li>
                <li>Multi-parameter visualization</li>
            </ul>
        `
    },
    {
        title: "Multi-Format Data Export",
        subtitle: "Flexible Data Management",
        content: `
            <ul>
                <li><strong>Excel Export:</strong> Detailed spreadsheet analysis</li>
                <li><strong>CSV Format:</strong> Universal compatibility</li>
                <li><strong>PDF Reports:</strong> Professional documentation</li>
                <li><strong>Custom Date Range:</strong> Selective data export</li>
                <li><strong>Automated Charts:</strong> Visual data representation</li>
            </ul>
        `
    },
    {
        title: "Smart Status Indicators",
        subtitle: "Intelligent Monitoring",
        content: `
            <ul>
                <li>Color-coded status badges</li>
                <li>Automatic threshold alerts</li>
                <li>Real-time status updates</li>
                <li>Visual health indicators</li>
                <li>Quick assessment system</li>
            </ul>
        `
    },
    {
        title: "User-Friendly Interface",
        subtitle: "Modern Design",
        content: `
            <ul>
                <li>Clean, intuitive layout</li>
                <li>Responsive design</li>
                <li>Dark/Light theme</li>
                <li>Easy navigation</li>
                <li>Mobile-friendly interface</li>
            </ul>
        `
    },
    {
        title: "Data Management Features",
        subtitle: "Efficient Control",
        content: `
            <ul>
                <li>Date range filtering</li>
                <li>Individual record deletion</li>
                <li>Bulk data clearing</li>
                <li>Animated transitions</li>
                <li>Automatic data organization</li>
            </ul>
        `
    },
    {
        title: "Professional Reporting",
        subtitle: "Comprehensive Documentation",
        content: `
            <ul>
                <li>Detailed PDF reports</li>
                <li>Automated chart generation</li>
                <li>Statistical analysis</li>
                <li>Professional formatting</li>
                <li>Custom date ranges</li>
            </ul>
        `
    },
    {
        title: "Security & Reliability",
        subtitle: "Robust Platform",
        content: `
            <ul>
                <li>Secure data handling</li>
                <li>Error prevention</li>
                <li>Multiple backup options</li>
                <li>Stable performance</li>
                <li>Regular updates</li>
            </ul>
        `
    },
    {
        title: "Future-Ready",
        subtitle: "Scalable Solution",
        content: `
            <ul>
                <li>API integration ready</li>
                <li>Expandable features</li>
                <li>Regular updates</li>
                <li>Mobile compatibility</li>
                <li>Cloud-ready architecture</li>
            </ul>
        `
    },
    {
        title: "Thank You",
        subtitle: "Contact Information",
        content: `
            <ul>
                <li>Website: www.kakapharmacy.com</li>
                <li>Email: contact@kakapharmacy.com</li>
                <li>Phone: +1 (XXX) XXX-XXXX</li>
                <li>Social Media: @KakaPharmacy</li>
            </ul>
        `
    }
]; 